"""Original COMP580 experimental agent; no NanoAgent implementation is used."""

__version__ = "0.1.0"
